<?php 

require_once ('Model/model.php');

function fetchAllReviews(){
	return showAllReview();

$reviews = $data["id"];

}
